-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-07-2024 a las 19:28:55
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `suigcedh7`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rel_licencias_personal`
--

CREATE TABLE `rel_licencias_personal` (
  `id_rel_licencia_personal` int(11) NOT NULL,
  `id_detalle_usuario` int(11) NOT NULL,
  `no_consec` int(11) NOT NULL,
  `tipo_licencia` int(11) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_termino` date NOT NULL,
  `no_dias` int(11) NOT NULL,
  `observaciones` varchar(500) COLLATE utf8_spanish_ci DEFAULT NULL,
  `documento` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `terminado` int(11) NOT NULL,
  `fecha_creacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `rel_licencias_personal`
--

INSERT INTO `rel_licencias_personal` (`id_rel_licencia_personal`, `id_detalle_usuario`, `no_consec`, `tipo_licencia`, `fecha_inicio`, `fecha_termino`, `no_dias`, `observaciones`, `documento`, `terminado`, `fecha_creacion`) VALUES
(7, 88, 1, 4, '2024-06-26', '2024-06-26', 12, '2', 'condiciones (1).pdf', 1, '2024-06-26'),
(8, 88, 2, 3, '2024-06-25', '2024-06-25', 3, '3r222', '', 1, '2024-06-26'),
(9, 115, 1, 3, '2024-06-26', '2024-06-26', 4, 'def', 'Adobe Scan 18 may 2023.pdf', 1, '2024-06-26'),
(10, 88, 3, 3, '2024-06-26', '2024-06-30', 1, '22323ffgfgf111', 'DISTORSIONES.pdf', 1, '2024-06-26'),
(11, 115, 2, 3, '2024-06-26', '2024-06-26', 4, 'gfdd', 'CEPERIIIversionfinal.pdf', 1, '2024-06-26'),
(12, 88, 4, 3, '2024-01-08', '2024-07-04', 171, '1', 'Adobe Scan 18 may 2023.pdf', 0, '2024-06-27'),
(13, 88, 5, 3, '2024-05-29', '2024-06-24', 27, '1', 'condiciones (1).pdf', 1, '2024-06-27'),
(14, 100, 1, 3, '2024-06-17', '2024-07-09', 15, 'Prueba', 'Control de Asistencias.pdf', 0, '2024-07-01'),
(15, 97, 1, 3, '2024-07-03', '2024-07-19', 16, 'Prueba número 7 de licencia personal.', 'CONSENTIMIENTO INFORMADO 4.pdf', 0, '2024-07-03'),
(16, 92, 1, 3, '2024-07-01', '2024-07-22', 21, '', 'estado_cuenta.pdf', 0, '2024-07-03'),
(17, 94, 1, 3, '2024-07-03', '2024-07-10', 7, '{}ñ}jl}l}ñl', 'CONSENTIMIENTO INFORMADO 4.pdf', 0, '2024-07-03');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `rel_licencias_personal`
--
ALTER TABLE `rel_licencias_personal`
  ADD PRIMARY KEY (`id_rel_licencia_personal`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `rel_licencias_personal`
--
ALTER TABLE `rel_licencias_personal`
  MODIFY `id_rel_licencia_personal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
