CREATE TABLE `rel_periodos_vac` (
  `id_rel_periodo_vac` int(11) NOT NULL,
  `id_rel_vacaciones` int(11) NOT NULL,
  `semana1_1` date DEFAULT NULL,
  `semana1_2` date DEFAULT NULL,
  `usuario_creador` int(11) NOT NULL,
  `fecha_creacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `rel_periodos_vac`
  ADD PRIMARY KEY (`id_rel_periodo_vac`);

ALTER TABLE `rel_periodos_vac`
  MODIFY `id_rel_periodo_vac` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
COMMIT;