CREATE TABLE `rel_vacaciones` (
  `id_rel_vacaciones` int(11) NOT NULL,
  `id_detalle_usuario` int(11) NOT NULL,
  `id_cat_periodo_vac` int(11) NOT NULL,
  `derecho_vacas` int(11) NOT NULL,
  `observaciones` text DEFAULT NULL,
  `ejercicio` varchar(5) NOT NULL,
  `usuario_creador` int(11) NOT NULL,
  `fecha_creacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `rel_vacaciones`
  ADD PRIMARY KEY (`id_rel_vacaciones`);

ALTER TABLE `rel_vacaciones`
  MODIFY `id_rel_vacaciones` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
COMMIT;